<?php $__env->startSection('title', '| Users'); ?>

<?php $__env->startSection('content'); ?>


<!--begin::Main-->
 <?php  
    $role_name = Auth::user()->roles()->pluck('name')->implode(' ');
    $role_id = Auth::user()->roles()->pluck('id')->implode(' ');
    $modulePermission = Illuminate\Support\Facades\DB::table('role_has_permissions')->join('permissions', 'role_has_permissions.permission_id', '=', 'permissions.id')->where('permissions.parent_id','1')->where('role_id',$role_id)->select('permissions.id')->get()->pluck('id')->toArray();
    
    //print_r($myData);
  ?>
   <style type="text/css">
  .table td,.table th {
    border: 1px solid #EBEDF3 ! important;
  }
</style>    
<!--begin::Entry-->
<div class="d-flex flex-column-fluid">
   <!--begin::Container-->
     <div class=" container ">
        <!--begin::Card-->
        <div class="card card-custom">
          <!--begin::Header-->
           <div class="card-header flex-wrap border-0 pt-6 pb-0">
              <div class="card-title">
                
              </div>
              <div class="card-toolbar">
                <a href="<?php echo e(URL('/admin/category')); ?>" style="margin-left: 10px;" class="btn btn-primary font-weight-bolder">Category List</a>
                 <!--end::Button-->
              </div>
           </div>
           <!--end::Header-->
           <!--begin::Body-->
                <div class="card-body">
         
          
         
          <table class="table" id="myTable" style="margin-top: 20px;">
            <thead>
              <tr>
                 <th width="30%">Sr.No.</th>
                 <th width="30%">Name</th>
              </tr>
            </thead>
            <tbody class="row_position">
            <?php $count = 1; ?>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="<?php echo $value->id; ?>" style="cursor: all-scroll;" >
                  <td><?php echo e($count); ?></td>
                  <td><?php echo e($value->name); ?></td>
                       
                </tr>
              <?php $count++; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            </tbody>
          </table>
          
        </div>
           <!--end::Body-->
        </div>
        <!--end::Card-->
     </div>
   <!--end::Container-->
</div>
<!--end::Entry-->
         
<!--end::Main-->



<?php $__env->stopSection(); ?>


<?php $__env->startSection('extrajs'); ?>
<style type="text/css">
  .modal-backdrop {
    background: transparent;
  }
</style>
<script src="<?php echo e(asset('assets/backend')); ?>/js/jquery-ui.min_1.js"></script>
<script type="text/javascript">
  var $sortable = $( "#myTable > tbody" );
  $sortable.sortable({
      stop: function ( event, ui ) {
          var parameters = $sortable.sortable( "toArray" );
             $.ajax({
        headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url: '<?php echo URL('/') ?>/admin/chnageCategoryOrder',
        type: 'POST',
        data: {value:parameters},
        success:function(response) { 
         location.reload();
        },
        error:function(){ alert('error');}
        }); 

         
      }
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>