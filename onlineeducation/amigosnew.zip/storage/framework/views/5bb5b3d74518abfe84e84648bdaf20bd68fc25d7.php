<?php $__env->startSection('title', '| Permissions'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <!-- Page-Title -->
  <div class="row">
    <div class="col-sm-12">
      <div class="page-title-box">
        
       <!--  <h4 class="page-title">Available Permissions</h4> -->
      </div>
    </div> 
  </div>
  <?php if(count($errors) > 0): ?>
  <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
  </div>
<?php endif; ?>
  <?php if(Session::has('message')): ?>
    <div class="alert alert-success login-success"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <?php echo Session::get('message'); ?> </div>
  <?php endif; ?>
  <!-- end page title end breadcrumb -->
  <div class="row">
    <div class="col-lg-12">
      <div class="card m-b-30">
        <div class="card-body">
          <ul class="nav nav-tabs" id="myTab" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home"
                  aria-selected="true">General Setting</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile"
                  aria-selected="false">App Setting</a>
              </li>
 
          </ul>

           
            <?php echo Form::open(array('url' => 'admin/websettingupd')); ?>

            <?php echo e(Form::hidden('id',$webseting->id)); ?>

<div class="tab-content" id="myTabContent">
      <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        
            <div class="form-group" style="margin-top: 20px;">
              <?php echo e(Form::label('website_name', 'Website Name')); ?>

              <div>
                <?php echo e(Form::text('website_name',$webseting->website_name , array('class' => 'form-control','required'=>'required'))); ?>

                
              </div>
            </div>
             <div class="form-group">
              <?php echo e(Form::label('email', 'Email')); ?>

              <div>
                <?php echo e(Form::email('email',$webseting->email , array('class' => 'form-control','required'=>'required'))); ?>

                
              </div>
            </div>
             <div class="form-group">
              <?php echo e(Form::label('address', 'Address')); ?>

              <div>
                <?php echo e(Form::text('address',$webseting->address , array('class' => 'form-control','required'=>'required'))); ?>

                
              </div>
            </div>

            <div class="form-group">
              <?php echo e(Form::label('mobile', 'Mobile')); ?>

              <div>
                <?php echo e(Form::number('mobile',$webseting->mobile , array('class' => 'form-control','required'=>'required'))); ?>

                
              </div>
            </div>
      </div>
      <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
        <div class="form-group" style="margin-top: 20px;">
              <?php echo e(Form::label('Near By Distance In KM', 'Near By Distance In KM')); ?>

              <div>
                <?php echo e(Form::text('near_by_distance',$webseting->near_by_distance , array('class' => 'form-control','required'=>'required'))); ?>

                
              </div>
            </div>

           
      
      <div class="form-group">
              <?php echo e(Form::label('Whatapp No', 'Whatapp No')); ?>

              <div>
                <?php echo e(Form::number('whatapps_no',$webseting->whatapps_no , array('class' => 'form-control','required'=>'required'))); ?>

                
              </div>
            </div>
      
      <div class="form-group">
              <?php echo e(Form::label('Support No', 'Support No')); ?>

              <div>
                <?php echo e(Form::number('sapport_no',$webseting->sapport_no , array('class' => 'form-control','required'=>'required'))); ?>

                
              </div>
            </div>
        
      </div>
</div>
            <div class="form-group m-b-0">
              <div>
                <button type="submit" class="btn btn-primary waves-effect waves-light"> Submit </button>
                <button type="reset" class="btn btn-secondary waves-effect m-l-5"> Cancel </button>
              </div>
            </div>
         <?php echo Form::close(); ?>

        </div>
      </div>
    </div>
    <!-- end col -->
    
    <!-- end col -->
  </div>
  <!-- end row -->
</div>
<!-- end container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>