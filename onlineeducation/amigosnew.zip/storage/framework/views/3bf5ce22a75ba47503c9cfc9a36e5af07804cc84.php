<?php $__env->startSection('title', '| Student'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <!-- Page-Title -->
  <div class="row">
    <div class="col-sm-12">
      <div class="page-title-box">
      </div>
    </div> 
  </div>
      <?php if(count($errors) > 0): ?>
      <div class="alert alert-danger">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
    <?php endif; ?>
  
  
  <?php if(Session::has('message')): ?>
    <div class="alert alert-success login-success"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <?php echo Session::get('message'); ?> </div>
  <?php endif; ?>
  <!-- end page title end breadcrumb -->
  
  <div class="row">
    <div class="col-lg-12">
      <div class="card m-b-30">
        <div class="card-body">
         
          
           <?php if(Request::segment(4)==='edit'): ?>
           <?php echo e(Form::model($user, array('route' => array('customer.update', $user->id), 'method' => 'PUT',  'enctype'=>'multipart/form-data', 'id' => 'studentForm'))); ?> 
            
            <?php            
              $name               = $user->name;
              $email              = $user->email;
              $mobile_number      = $user->mobile_number;
              $last_name          = $user->last_name;
              $image              = $user->profile_pic;      
            ?>
            <?php echo Form::hidden('id',$user->id); ?>

            
            <?php else: ?>
            <?php echo e(Form::open(array('url' => 'admin/customer', 'enctype'=>'multipart/form-data', 'id' => 'studentForm'))); ?>

            <?php echo Form::hidden('CreatedBy',Auth::user()->id); ?>

            <?php 
              $name             = '';
              $last_name        = '';
              $email            = '';
              $mobile_number    = '';
              $image            = '';             
            ?>
            <?php endif; ?>
          

          
          <div class="row">
          
          </div>
            <div class="row"> 
            
            <div class="col-md-6">
              <div class="form-group">
               <?php echo e(Form::label('name', 'Name')); ?>

               <span class="text text-danger">*</span>
                <div>
                   
               <?php echo e(Form::text('name', $name, array('class' => 'form-control','placeholder'=>'Name','id'=>'name'))); ?>

                </div>
              </div>
            </div>



            <div class="col-md-6">
              <div class="form-group">
              <?php echo e(Form::label('last_name', 'Last Name')); ?>

              <div>

              <?php echo e(Form::text('last_name', $last_name, array('class' => 'form-control','placeholder'=>'Last Name'))); ?>

              </div>
              </div>
            </div>

            
            <div class="col-md-6">
              <div class="form-group">
                <?php echo e(Form::label('email', 'Email')); ?>

                <span class="text text-danger">*</span>
                <div>
                  <?php echo e(Form::email('email', $email, array('class' => 'form-control',  'placeholder'=>'Email', 'id'=>'email'))); ?>

                </div>
              </div>
            </div>   


            <div class="col-md-6">
              <div class="form-group">
              <?php echo e(Form::label('Contact Number', 'Contact Number')); ?>

              <span class="text text-danger">*</span>
              <div>
                 
              <?php echo e(Form::number('mobile_number', $mobile_number, array('class' => 'form-control only-numeric','placeholder'=>'Contact Number'))); ?>

              </div>
              </div>
            </div>
         
            <div class="col-md-6">
                  <div class="form-group"> 
                    <label for="Language Code" id="code">Image</label>
                    <div> 
                      <?php
                        $url = 'assets/images/user.png';
                        if($image){
                        $url = 'public/assets/img/customer/'.$image;
                        }
                      ?>
                      <img id="blah" src="<?php echo e(asset($url)); ?>" style="height: 150px;width: 150px;">
                      <input id="imgInp" type="file" name="file">
                    </div>
                  </div>
            </div>    
             
            </div>
            
           
            <div class="form-group m-b-0">
              <div>
                <button type="submit" class="btn btn-primary waves-effect waves-light"> Submit </button>
                <a href="<?php echo e(URL('admin/customer')); ?>" type="reset" class="btn btn-secondary waves-effect m-l-5"> Cancel </a>
              </div>
            </div>
         <?php echo Form::close(); ?>

        </div>
      </div>
    </div>
    <!-- end col -->
   
    <!-- end col -->
  </div>
  <!-- end row -->
</div>
<!-- end container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extrajs'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/jquery.datetimepicker.css')); ?>">
<script src="<?php echo e(asset('public/js/jquery.datetimepicker.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/jquery.datetimepicker.full.min.js')); ?>"></script>

<script type="text/javascript">
  $( function() {
    $('.select').select2({
      width: '100%',
      placeholder: 'Select Language',
    });  
  });

 
</script>
<script type="text/javascript">


  function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#blah').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}

$("#imgInp").change(function() {
  readURL(this);
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>