<?php $__env->startSection('title', '| Users'); ?>

<?php $__env->startSection('content'); ?>


<!--begin::Main-->

      
          <!--begin::Entry-->
            <div class="d-flex flex-column-fluid">
               <!--begin::Container-->
               <div class="container ">
                  <!--begin::Dashboard-->
                  <div class="container-fluid">
  <!-- Page-Title -->
  <div class="row">
    <div class="col-sm-12">
      <div class="page-title-box">
        
        
      </div>
    </div> 
  </div>
      <?php if(count($errors) > 0): ?>
      <div class="alert alert-danger">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
    <?php endif; ?>
  
  
  <?php if(Session::has('message')): ?>
    <div class="alert alert-success login-success"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <?php echo Session::get('message'); ?> </div>
  <?php endif; ?>
  <!-- end page title end breadcrumb -->
  
  <div class="row">
    <div class="col-lg-12">
      <div class="card m-b-30">
        <div class="card-body">
          
           <?php if(Request::segment(4)==='edit'): ?>
           <?php echo e(Form::model($store, array('route' => array('store.update', $store->id), 'method' => 'PUT', 'id' => 'storeForm',  'enctype'=>'multipart/form-data'))); ?> 
            
            <?php  
			
                $roleid             = $store->user_type;
                $name               = $store->name;
                $email              = $store->email;
                $Phone              = $store->Phone;
                $readonly           = 'readonly';
                $zipcode            = $store->zipcode;
                $latitude           = $store->latitude;
                $longitude          = $store->longitude;
                $address            = $store->address;
                $image              = $store->image;
				$store_logo         = $store->storelogo;
                $city              = $store->city;
                $ratting              = $store->ratting;
            ?>
            <?php echo Form::hidden('id',$store->id); ?>

            
            <?php else: ?>
            <?php echo e(Form::open(array('url' => 'admin/store', 'enctype'=>'multipart/form-data','id' => 'userForm'))); ?>

            <?php 
               
                $name             = '';
                $email            = '';
                $Phone            = '';
                $zipcode          = '';
                $latitude         = '';
                $longitude        = '';
                $address          = '';
                $readonly         = '';
                $image            = '';
                $city             = '';
                $ratting          = '';
				$store_logo       ='';
               
                             
            ?>
            <?php endif; ?>

          
          <div class="row">
          
          </div>
            <div class="row"> 
            <div class="col-md-4">
              <div class="form-group">
               <?php echo e(Form::label('Category', 'Category')); ?>

               <span class="text text-danger">*</span>
                <div>
                   
               <select class="form-control select2" name="category[]" multiple="" required="">
                    <option value="all" >Select Category</option>
                    <?php $__currentLoopData = $categoryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				     <option  value="<?php echo e($category->id); ?>" <?php if(in_array($category->id,$category_ids)): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
               <?php echo e(Form::label('Store Name', 'Store Name')); ?>

               <span class="text text-danger">*</span>
                <div>
                   
               <?php echo e(Form::text('name', $name, array('class' => 'form-control','placeholder'=>'Name','id'=>'name'))); ?>

                </div>
              </div>
            </div>

            
            <div class="col-md-4">
              <div class="form-group">
                <?php echo e(Form::label('email', 'Email')); ?>

                <span class="text text-danger">*</span>
                <div>
                  <?php echo e(Form::email('email', $email, array('class' => 'form-control','placeholder'=>'Email','id'=>'email',$readonly))); ?>

                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
              <?php echo e(Form::label('Contact Number', 'Contact Number')); ?>

              <span class="text text-danger">*</span>
              <div>
                 
              <?php echo e(Form::number('mobile_number', $Phone, array('class' => 'form-control only-numeric','placeholder'=>'Contact Number'))); ?>

              </div>
              </div>
            </div>

            <div class='col-md-4 form-group'>
                <?php echo e(Form::label('Address', 'Address')); ?>

                <span class="text text-danger">*</span>
                <div>
                  <?php echo e(Form::text('address', $address, array('class' => 'form-control','placeholder'=>'Address','id'=>'autocomplete'))); ?>

                </div>
            </div>

            <div class="col-md-4">
              <div class="form-group">
              <?php echo e(Form::label('City', 'City')); ?>

              <div>

              <?php echo e(Form::text('city', $city, array('class' => 'form-control','placeholder'=>'City','id'=>'city','readonly'=>'readonly'))); ?>

              </div>
              </div>
            </div>
            <div class="col-md-2">
              <div class="form-group">
              <?php echo e(Form::label('Latitude', 'Latitude')); ?>

              <div>

              <?php echo e(Form::text('latitude', $latitude, array('class' => 'form-control','placeholder'=>'Latitude','id'=>'latitude','readonly'=>'readonly'))); ?>

              </div>
              </div>
            </div>

            <div class="col-md-2">
              <div class="form-group">
              <?php echo e(Form::label('Longitude', 'Longitude')); ?>

              <div>

              <?php echo e(Form::text('longitude', $longitude, array('class' => 'form-control','placeholder'=>'Longitude','id'=>'longitude','readonly'=>'readonly'))); ?>

              </div>
              </div>
            </div>
           <div class="col-md-4">
              <div class="form-group">
              <?php echo e(Form::label('Zipcode', 'Zipcode')); ?>

              <div>

              <?php echo e(Form::text('zipcode', $zipcode, array('class' => 'form-control','placeholder'=>'Zipcode'))); ?>

              </div>
              </div>
            </div>
              <div class="col-md-4">
              <div class="form-group">
              <?php echo e(Form::label('Ratting', 'Ratting')); ?>

              <div>

              <?php echo e(Form::number('ratting', $ratting, array('class' => 'form-control','placeholder'=>'Ratting','max'=>'5'))); ?>

              </div>
              </div>
            </div>

            
              <div class="col-md-4">
              <div class="form-group">
              <?php echo e(Form::label('Password', 'Password')); ?>

              <div>
                <input  type="password" autocomplete="off" class="form-control form-control" name="password" <?php if(Request::segment(4)!='edit'): ?> required <?php endif; ?> placeholder="Password">
           
              </div>
              </div>
            </div>

            <div class="col-md-3">
                  <div class="form-group"> 
                    <label for="Language Code" id="code">KYC Verification Documents</label>
                    <div> 
                      <?php
                        $url = 'assets/images/user.png';
                        if($image){
                        $url = 'public/assets/img/store/'.$image;
                        }
                      ?>
                      <img id="blah" src="<?php echo e(asset($url)); ?>" style="height: 150px;width: 150px;">
                      <input id="imgInp" type="file" name="file">
                    </div>
                  </div>
            </div>

               <div class="col-md-3">
                  <div class="form-group"> 
                    <label for="Language Code" id="code">Store Logo</label>
                    <div> 
                      <?php
                        $url1 = 'assets/images/user.png';
                        if($store_logo){
                        $url1 = 'public/assets/img/store/'.$store_logo;
                        }
                      ?>
                      <img id="blah1" src="<?php echo e(asset($url1)); ?>" style="height: 150px;width: 150px;">
                      <input id="storeLogo" type="file" name="storelogo">
                    </div>
                  </div>
            </div>  			
            

             
            </div>
            
           
            <div class="form-group m-b-0">
              <div>
                <button type="submit" class="btn btn-primary waves-effect waves-light"> Submit </button>
                <a href="<?php echo e(URL('admin/store')); ?>" type="reset" class="btn btn-secondary waves-effect m-l-5"> Cancel </a>
              </div>
            </div>
         <?php echo Form::close(); ?>

        </div>
      </div>
    </div>
    <!-- end col -->
   
    <!-- end col -->
  </div>
  <!-- end row -->
</div>
<!-- end container -->
               </div>
               <!--end::Container-->
            </div>
          <!--end::Entry-->
         
<!--end::Main-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extrajs'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/jquery.datetimepicker.css')); ?>">
<script src="<?php echo e(asset('public/js/jquery.datetimepicker.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/jquery.datetimepicker.full.min.js')); ?>"></script>


   <script src="https://maps.google.com/maps/api/js?key=AIzaSyAgAlL4lJvPU9v3nOa_GnUmfsPSkX11Yrg&libraries=places&callback=initAutocomplete" type="text/javascript"></script>

   <script>
    $( function() {
    $('.select2').select2({ width: '100%' });  
  });
      $('#autocomplete').on('keypress', function(e) {
        return e.which !== 13;
      });
       $(document).ready(function() {
            $("#lat_area").addClass("d-none");
            $("#long_area").addClass("d-none");
       });
   </script>


   <script>
       google.maps.event.addDomListener(window, 'load', initialize);

       function initialize() {
            var options = {
             componentRestrictions: {country: "IN"}
           };
           var input = document.getElementById('autocomplete');
           var autocomplete = new google.maps.places.Autocomplete(input,options);
           autocomplete.addListener('place_changed', function() {
               var place = autocomplete.getPlace();
               console.log('place',place);
               console.log('place',);
               $('#city').val(place.vicinity);
               $('#latitude').val(place.geometry['location'].lat());
               $('#longitude').val(place.geometry['location'].lng());

            // --------- show lat and long ---------------
               $("#lat_area").removeClass("d-none");
               $("#long_area").removeClass("d-none");
           });
       }
    </script>

<script type="text/javascript">
  $( function() {
    $('.select').select2({
      width: '100%',
      placeholder: 'Select Language',
    });  
  });

 
</script>
<script type="text/javascript">


  function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#blah').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}

  function readURL1(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#blah1').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}

$("#imgInp").change(function() {
  readURL(this);
});



$("#storeLogo").change(function() {
  readURL1(this);
});


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>