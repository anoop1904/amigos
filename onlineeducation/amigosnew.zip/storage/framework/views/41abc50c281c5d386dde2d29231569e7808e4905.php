<?php $__env->startSection('title', '| Users'); ?>

<?php $__env->startSection('content'); ?>


<!--begin::Main-->
 <?php  
    $role_name = Auth::user()->roles()->pluck('name')->implode(' ');
    $role_id = Auth::user()->roles()->pluck('id')->implode(' ');
    $modulePermission = Illuminate\Support\Facades\DB::table('role_has_permissions')->join('permissions', 'role_has_permissions.permission_id', '=', 'permissions.id')->where('permissions.parent_id','1')->where('role_id',$role_id)->select('permissions.id')->get()->pluck('id')->toArray();
    
    //print_r($myData);
  ?>
<style type="text/css">
  .table td,.table th {
    border: 1px solid #EBEDF3 ! important;
  }
</style>    
<!--begin::Entry-->
<div class="d-flex flex-column-fluid">
   <!--begin::Container-->
     <div class=" container ">
        <!--begin::Card-->
        <div class="card card-custom">
           <!--begin::Header-->
           <div class="card-header flex-wrap border-0 pt-6 pb-0">
              <div class="card-title">
              </div>
              <div class="card-toolbar">
            
                 <!--begin::Button-->
                 <a href="<?php echo e(URL('admin/store/create')); ?>" class="btn btn-primary font-weight-bolder">
                    <span class="svg-icon svg-icon-md">
                       <!--begin::Svg Icon | path:assets/media/svg/icons/Design/Flatten.svg-->
                       <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                          <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                             <rect x="0" y="0" width="24" height="24"/>
                             <circle fill="#000000" cx="9" cy="15" r="6"/>
                             <path d="M8.8012943,7.00241953 C9.83837775,5.20768121 11.7781543,4 14,4 C17.3137085,4 20,6.6862915 20,10 C20,12.2218457 18.7923188,14.1616223 16.9975805,15.1987057 C16.9991904,15.1326658 17,15.0664274 17,15 C17,10.581722 13.418278,7 9,7 C8.93357256,7 8.86733422,7.00080962 8.8012943,7.00241953 Z" fill="#000000" opacity="0.3"/>
                          </g>
                       </svg>
                       <!--end::Svg Icon-->
                    </span>
                    New Record
                 </a>
                 <!--end::Button-->
              </div>
           </div>
           <!--end::Header-->
           <!--begin::Body-->
           <div class="card-body">
              <?php if(Session::has('message')): ?>
                <div class="alert alert-success login-success">
                   <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <?php echo Session::get('message'); ?> 
                </div>
              <?php endif; ?>
              <form class="kt-form kt-form--fit mb-15" method="get">
                      <div class="row">
                       
                        <div class="col-lg-3 mb-lg-0 mb-6">
                          <label>Name</label>
                           <input type="text" name="name" class="form-control" value="<?php if(isset($_GET['name'])){  echo $_GET['name']; } ?>" placeholder="Name" >
                        </div>
                        <div class="col-lg-3 mb-lg-0 mb-6">
                          <label>Email</label>
                        <input type="text" name="email" class="form-control" value="<?php if(isset($_GET['email'])){  echo $_GET['email']; } ?>" placeholder="Email" >
                        </div>
                       <!--  <div class="col-lg-3 mb-lg-0 mb-6">
                            <label>Date Range</label>
                             <input type="text" autocomplete="off" class="form-control" name="date_filter" id="date_filter" value="<?php if(isset($_GET['date_filter'])){  echo $_GET['date_filter']; } ?>"/>
                         </div>

                          <div class="col-lg-3 mb-lg-0 mb-6">
                            <label>Date</label>
                              <input type="date" name="date" class="form-control" value="<?php if(isset($_GET['date'])){  echo $_GET['date']; } ?>" placeholder="Date" >
                          </div> -->
                      
                        <div class="col-lg-3 mb-lg-0 mb-6">
                          <label>Status</label>
                          <select class="form-control" name="status">
                            <option value="all">All</option>
                            <option <?php if(isset($_GET['status'])){ if($_GET['status']=='1'){ echo 'selected';} } ?> value="1">Active</option>
                            <option <?php if(isset($_GET['status'])){ if($_GET['status']=='0'){ echo 'selected';} } ?> value="0">Deactive</option>
                          </select>
                        </div>
                         <div class="col-lg-3 mb-lg-0 mb-6" style="margin-top: 25px;">
                          <button type="submit" class="btn btn-primary btn-primary--icon" id="kt_search">
                          <span>
                            <i class="la la-search"></i>
                            <span>Search</span>
                          </span>
                        </button>&nbsp;&nbsp;  <a class="btn btn-danger btn-secondary--icon" id="kt_reset" href="<?php echo URL('/') ?>/admin/store">
                          <span>
                            <i class="la la-close"></i>
                            <span>Reset</span>
                          </span>
                        </a>
                        </div>
                  </form>
          <table class="table" id="myTable" style="margin-top: 20px;">
            <thead>
              <tr>
                <th width="5%" >KYC</th>
				<th width="5%">Store Logo</th>
                <th width="10%">Store Name</th>
                <th width="10%">Category</th>
                <th width="10%">Email</th>
                <th width="8%">Contact Number</th>
				<th width="5%">Payment Status</th>
				<th width="10%">Payment Link</th>				
                <th width="5%">Status</th>
                <th width="20%">Operations</th>
                </tr>
            </thead>
            <tbody>
           <?php $count = 1; ?>
            <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php   $category=getCategoryName($user['checkcategory']);?>
            <tr>
                    <td> 
                          <?php
                          $url = 'assets/images/user.png';
                          if($user->image){
                          $url = '/public/assets/img/store/'.$user->image;
                          }
                          ?>
                          <img src="<?php echo e(asset($url)); ?>"  style="height: 80px;width: 80px;">
                    </td>
					
					 <td> 
                          <?php
                          $url1 = 'assets/images/user.png';
                          if($user->storelogo){
                          $url1 = '/public/assets/img/store/'.$user->storelogo;
                          }
                          ?>
                          <img src="<?php echo e(asset($url1)); ?>" style="height: 80px;width: 80px;">
                    </td>
					
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e(implode(',',$category)); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->mobile_number); ?></td>
					
					<td>
                        <?php if($user->payment_status): ?>
                          <div>
                          <span class="text text-success " data_val="<?= $user->id ?>" >Done</span>
						  </div>
                        <?php else: ?>
                          <div>
                          <span class="text text-danger " data_val="<?= $user->id ?>" >Pending</span>
						  </div>
                        <?php endif; ?>
                    </td>
					
					<td>
                        <?php if(!empty($user->payment_link)): ?>
                          <div>
                          <span class="text text-success " data_val="<?= $user->id ?>" >Send</span>
						  </div>
                        <?php else: ?>
                          <div>
                          <span class="text text-danger " data_val="<?= $user->id ?>" >Not Send</span>
						  </div>
                        <?php endif; ?>
                    </td>
					
                    <td>
                        <?php if($user->IsActive): ?>
                          
                          <div>
                            <input type="checkbox" class="switch myswitch" cstate="" id="myswitch<?php echo e($user->id); ?>" cid="<?php echo e($user->id); ?>"  data-backdrop="static" data-keyboard="false" checked />
                          </div>
                        <?php else: ?>
                          
                          <div>
                            <input type="checkbox" class="switch myswitch" cstate="" id="myswitch<?php echo e($user->id); ?>" cid="<?php echo e($user->id); ?>"  data-backdrop="static" data-keyboard="false"/>
                          </div>
                        <?php endif; ?>
                    </td>

                    <td> 
        <a href="<?php echo e(route('store.edit', $user->id)); ?>" class="btn btn-info fa fa-pencil-square-o" style="float:right;"  title="Edit"></a>
        <?php if(!$user->payment_status): ?>
		<span class="btn btn-secondary fa fa-eye payment_details" style="float:right;" data_val="<?= $user->id ?>"   title="Payment Details"  ></span>        	
		<?php endif; ?>	 
		 
		<?php echo e(Form::open(['method' => 'DELETE', 'route' => ['store.destroy', $user->id] ])); ?>

        <button type="submit" title="Delete" class="btn btn-danger la la-trash" style="float:right;" onclick="return confirm('Do You want to Delete?')">
        </button> 
     
        
	<?php if($user->payment_link): ?>
				<?php if(!$user->payment_status): ?>
        <span class="btn btn-success payment_link_status fa fa-send " data_val="<?= $user->id ?>" data_plain_id="<?= $user->plain_id ?>"  aria-hidden="true" title="Re-send"></span>
                <?php endif; ?>	   
	<?php else: ?>    
		        <?php if(!$user->payment_status): ?> 
        <span class="btn btn-warning payment_link_status fa fa-send " data_val="<?= $user->id ?>" data_plain_id="<?= $user->plain_id ?>"  title="Send Link"> </span>
	            <?php endif; ?>
	<?php endif; ?>
		   <?php echo e(Form::close()); ?>

                    </td>
            </tr>
            <?php $count++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <tr>
              <td colspan="7">
                <?php 
             if(isset($_GET['name'])&& isset($_GET['email']) && isset($_GET['status']))
               {
               ?>
                 <?php echo e($stores->appends(['name' => $_GET['name'],'email' => $_GET['email'],'status' => $_GET['status']])->links()); ?>

              <?php  }
             else
             {
              ?>
             <?php echo e($stores->links()); ?>

            <?php } ?>
              </td>
            </tr>
            </tbody>
          </table>
          </div>
           <!--end::Body-->
        </div>
        <!--end::Card-->
     </div>
   <!--end::Container-->
</div>
<!--end::Entry-->
         
<!--end::Main-->
<!-- Payment Link modal start -->
<div class="modal fade" style="width:100% !important;" id="payment_link_status" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="max-width:800px !important;" role="document">
    <div class="modal-content">
	  <?php echo e(Form::open(array('url' => 'admin/paymentLink', 'enctype'=>'multipart/form-data','id' => 'userForm'))); ?>

      <div class="modal-header">
        <h5 class="modal-title" id="payment_link_status"><u>Payment Link</u></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
	  
            <?php 
                $payment_link       = '';	
            ?> 
            <div class="row">
			 <div class="col-md-12 payment_status" id="payment_status"  >
              <div class="form-group">
               <?php echo e(Form::label('Payment Type', 'Payment Type')); ?>

                <select class="form-control select2 payment_method" name="payment_method" >
                  <option selected="selected" value="" disabled="">Payment Type</option>
                  
				  <option   value="0">Phone Pey</option>
				  <option   value="1">Google Pay</option>
				  <option   value="2">UPI</option>
				  <option   value="3">PayTM</option>
                   
                </select>
              </div>
            </div>
			
             <div class="col-md-12">
			 <input type="hidden" name="storeid" id="storeid" />
              <div class="form-group">
               <?php echo e(Form::label('Payment Link', 'Payment Link')); ?>

                <div>
               <?php echo e(Form::text('payment_link', $payment_link, array('class' => 'form-control','placeholder'=>'Payment Link','id'=>'payment_link'))); ?>

                </div>
              </div>
            </div>
			
		
			</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" >Submit</button>
      </div>
	  <?php echo Form::close(); ?>

    </div>
  </div>
</div>
<!-- Payment Link status modal end -->


<!-- Payment Details modal start -->
<div class="modal fade" style="width:100% !important;" id="payment_details" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="max-width:800px !important;" role="document">
    <div class="modal-content">
	  <?php echo e(Form::open(array('url' => 'admin/paymentDetails', 'enctype'=>'multipart/form-data','id' => 'userForm'))); ?>

      <div class="modal-header">
        <h5 class="modal-title" id="payment_details"><u>Payment Details</u></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
	  
            <?php 
             $payment_method = '';
			 $payment_amount = '';
			 $payment_date   = '';
             $desctiption    = '';				
            ?> 
			
            <div class="row">
			  <div class="col-md-6">
			   <input type="hidden" name="Paymetn_storeid" id="Paymetn_storeid" />
              <div class="form-group">
               <?php echo e(Form::label('Payment Amount', 'Payment Amount')); ?>

                <div>
               <?php echo e(Form::text('payment_amount', $payment_amount, array('class' => 'form-control','placeholder'=>'Amount','id'=>'amount'))); ?>

                </div>
              </div>
            </div>
			
			  <div class="col-md-6">
              <div class="form-group">
               <?php echo e(Form::label('Payment Date', 'Payment Date')); ?>

                <div>
               <?php echo e(Form::date('payment_date', $payment_date, array('class' => 'form-control','placeholder'=>'Payment Date','id'=>'payment_date'))); ?>

                </div>
              </div>
            </div>
			
			 <div class="col-md-12">
			  <div class="form-group">
               <?php echo e(Form::label('Description', 'Description')); ?>

                <div>
               <?php echo e(Form::textarea('desctiption', $desctiption, array('class' => 'form-control','placeholder'=>'Discription','id'=>'description','row'=>'3'))); ?>

                </div>
              </div>
            </div>
			
			</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" >Submit</button>
      </div>
	  <?php echo Form::close(); ?>

    </div>
  </div>
</div>
<!-- Payment Details modal end -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('extrajs'); ?>
<script src="<?php echo e(asset('assets/backend')); ?>/js/pages/custom/user/list-datatable.js?v=7.0.6"></script>
</script>
<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css"/>
 <!-- BEGIN PAGE LEVEL PLUGINS -->
       
        <!-- END PAGE LEVEL PLUGINS -->
<script type="text/javascript">

$( function() {
    $('.select2').select2({ width: '100%' });  
  });
  
$(function() {

  $('input[name="date_filter"]').daterangepicker({
      autoUpdateInput: false,
      locale: {
          cancelLabel: 'Clear'
      }
  });

  $('input[name="date_filter"]').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
  });

  $('input[name="date_filter"]').on('cancel.daterangepicker', function(ev, picker) {
      $(this).val('');
  });

});

</script>
<script src="<?php echo e(asset('assets/backend')); ?>/js/pages/custom/user/list-datatable.js?v=7.0.6"></script>
</script>
<script>
$(".payment_link_status").on('click', function(event){
var cid = $(this).attr('data_val');
console.log(cid);
$("#storeid").val(cid);
$('#exampleModal').modal('hide');	
$('#payment_link_status').modal('show');
});

$(".payment_details").on('click', function(event){
var cid = $(this).attr('data_val');

$("#Paymetn_storeid").val(cid);
$('#exampleModal').modal('hide');	
$('#payment_details').modal('show');
});
 
</script>


<script>

$(document).on('click','.modal_value',function(){
    var rid = $(this).attr('rid');
	var cid = $(this).attr('data_val');
    console.log("cid = "+cid+" rid = "+rid);
     $.ajax({
        headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url: "<?php echo e(URL('admin/getOrderDetails')); ?>",
        type: 'POST',
        data: {cid:cid},
        success:function(response) { 
          var obj = JSON.parse(response);
		  console.log(obj);
          if(obj.status){
		   var total=0;
		   var htm ='';
		   $.each(obj.result,function(index,val){
			var waight_unit=val.waight+' '+val.unit.name;
			htm+="<tr><th scope='row'>"+(index+1)+"</th><td>"+val.product.name+"</td><td>"+val.amount+"</td><td>"+waight_unit+"</td><td>"+val.qty+"</td><td>"+(parseFloat(val.qty) * parseFloat(val.amount))+"</td></tr>"
		   total = total + (parseFloat(val.qty) * parseFloat(val.amount));
		   });
		   htm+="<tr><th scope='row' colspan='5' >Total</th><th >"+total+"</th><tr>";
		   console.log(total);
		   $('.tabledata').html(htm);
		   
       $('#exampleModal').modal('show');
          } 

        },
        error:function(){ alert('error');}
        }); 

  });
  
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>