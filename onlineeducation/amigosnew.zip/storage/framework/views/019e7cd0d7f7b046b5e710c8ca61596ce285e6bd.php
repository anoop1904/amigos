<?php $__env->startSection('title', '| Users'); ?>

<?php $__env->startSection('content'); ?>


<!--begin::Main-->
 <?php  
    $role_name = Auth::user()->roles()->pluck('name')->implode(' ');
    $role_id = Auth::user()->roles()->pluck('id')->implode(' ');
    $modulePermission = Illuminate\Support\Facades\DB::table('role_has_permissions')->join('permissions', 'role_has_permissions.permission_id', '=', 'permissions.id')->where('permissions.parent_id','1')->where('role_id',$role_id)->select('permissions.id')->get()->pluck('id')->toArray();
    
    //print_r($myData);
  ?>
<style type="text/css">
  .table td,.table th {
    border: 1px solid #EBEDF3 ! important;
  }
  .viewarea{
    background: lightgray;
    width: 50%;
    margin-left: 27%;
    margin-top: 3%;
    padding: 18px;
    border-radius: 13px;
  }

.wrapper { width:100%; margin:50px auto; }
.char-textarea { width:100%; height:100px; resize:none; }
.char-count { font-weight:bold; }
h4 { font-weight:normal; }
.row1{
  margin-bottom:12px;
}
</style>     
<!--begin::Entry-->

            <?php            
              $image =""; 
            ?>

<div class="d-flex flex-column-fluid">
   <!--begin::Container-->
     <div class=" container ">
        <!--begin::Card-->
        <div class="card card-custom">
           <!--begin::Header-->
        
           <!--end::Header-->
           <!--begin::Body-->
           <div class="card-body">
              <?php if(Session::has('message')): ?>
                <div class="alert alert-success login-success">
                   <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <?php echo Session::get('message'); ?> 
                </div>
              <?php endif; ?>
              <form class="kt-form kt-form--fit " method="post">
			          <div class="row">
			     
				        <div class="col-md-6">

                
                <div class="form-group">
                   <?php echo e(Form::label('Select store/Customer', 'Select Store/Customer')); ?>

                   <span class="text text-danger">*</span>
                    <div>     
                 <select class="form-control select2 select_type" name="select_type" class="select_type" required="">
                    <option value="all" >All</option>
				             <option   value="1">Store</option>
				             <option   value="2">Customer</option>
                  </select>
                    </div>
                  </div>

                  <div class="form-group">
                   <?php echo e(Form::label('Title', 'Title')); ?>

                   <span class="text text-danger">*</span>
                    <div>     
                      <input type="text" class="form-control" name="title" placeholder="Enter Title">
                    </div>
                  </div>
                  <div class="form-group">
                   <?php echo e(Form::label('Body', 'Body')); ?>

                   <span class="text text-danger">*</span>
                    <div>   
                    <textarea name="editor1"  data-length=100  class="char-textarea textarea_editor form-control" rows="6", cols="80" style="resize: none;"></textarea>
                     <h4><span class="char-count text-danger">100</span> chars remaining</h4>
                    </div>
                  </div>
             
                  <div class="form-group customers">
                   <?php echo e(Form::label('Customers', 'Customers')); ?>

                    <span class="text text-danger">*</span>
                    <div>
                    <select class="form-control select2" name="customers" multiple="" required="">
                    <option value="all" >All</option>
                    <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if(isset($_GET['customers'])){ if($_GET['customers']==$customers->id){ echo "selected";}} ?> value="<?php echo e($customers->id); ?>"><?php echo e($customers->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    </div>
                  </div>

                  <div class="form-group stores" style="display:none;" >
                     <?php echo e(Form::label('Stores', 'Stores')); ?>

                     <span class="text text-danger">*</span>
                      <div>
                      <select class="form-control select2 stores" name="stores" multiple="" required="">
                      <option value="all" >All</option>
                      <?php $__currentLoopData = $store; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $store_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option <?php if(isset($_GET['store_val'])){ if($_GET['store_val']==$store_val->id){ echo "selected";}} ?> value="<?php echo e($store_val->id); ?>"><?php echo e($store_val->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                     </div>
                  </div>

                  <div class="form-group ">
                    <label for="Language Code" id="code">Image</label>
                    <div> 
                      <?php
                        $url = 'assets/images/user.png';
                        if($image){
                        $url = 'public/assets/img/product/'.$image;
                        }
                      ?>
                      <img id="blah" src="<?php echo e(asset($url)); ?>" style="height: 150px;width: 150px;">
                      <input id="imgInp" type="file" name="file">
                    </div>
                  </div>


				  
				      <div class="form-group">
					        <button type="button" class="btn btn-success" >Submit</button>
					     </div>
          </div>
				
				 <div class="col-md-6">
				 <div class="viewarea" style="display:none;" >
				 <p class="temp_body"></p>
				 </div>
				  </div>
				  
				</div>
				
				
		   </form>
           <!--end::Body-->
        </div>
        <!--end::Card-->
     </div>
   <!--end::Container-->
</div>
<!--end::Entry-->
         
<!--end::Main-->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('extrajs'); ?>
<script src="<?php echo e(asset('assets/backend')); ?>/js/pages/custom/user/list-datatable.js?v=7.0.6"></script>
</script>
<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css"/>
 <!-- BEGIN PAGE LEVEL PLUGINS -->
       
        <!-- END PAGE LEVEL PLUGINS -->
<script type="text/javascript">
$(function() {
  $(".viewarea").hide();
  
  $('input[name="date_filter"]').daterangepicker({
      autoUpdateInput: false,
      locale: {
          cancelLabel: 'Clear'
      }
  });

});

 $( function() {
    $('.select2').select2({ width: '100%' });  
  });
  

 $(document).on('click','.modal_value',function(){
    var rid = $(this).attr('rid');
	var cid = $(this).attr('data_val');
    console.log("cid = "+cid+" rid = "+rid);
     $.ajax({
        headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url: "<?php echo e(URL('admin/getOrderDetails')); ?>",
        type: 'POST',
        data: {cid:cid},
        success:function(response) { 
          var obj = JSON.parse(response);
		  console.log(obj);
          if(obj.status){
			  
           // $('#subcategory'+rid).html(obj.result);
		   var total=0;
		   var htm ='';
		   $.each(obj.result,function(index,val){
			var waight_unit=val.waight+' '+val.unit.name;
			htm+="<tr><th scope='row'>"+(index+1)+"</th><td>"+val.product.name+"</td><td>"+val.amount+"</td><td>"+waight_unit+"</td><td>"+val.qty+"</td><td>"+(parseFloat(val.qty) * parseFloat(val.amount))+"</td></tr>"
		   total = total + (parseFloat(val.qty) * parseFloat(val.amount));
		   });
		   htm+="<tr><th scope='row' colspan='5' >Total</th><th >"+total+"</th><tr>";
		   console.log(total);
		   $('.tabledata').html(htm);
		   
       $('#exampleModal').modal('show');
          } 

        },
        error:function(){ alert('error');}
        }); 

  });


$(document).on('change','.smstemplate',function(){
	var id=$(this).val();
	console.log(id);
	  $.ajax({
        headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url: "<?php echo e(URL('admin/getSmsTemplate')); ?>",
        type: 'POST',
        data: {id:id},
        success:function(response) { 
          var obj = JSON.parse(response);
		
          if(obj.status){
			  $(".viewarea").show();
			  $( ".temp_body" ).text(obj.temp_details[0]['body']);
          } 

        },
        error:function(){ alert('error');}
        }); 
});
  $(".char-textarea").on("keyup",function(event){
  checkTextAreaMaxLength(this,event);
});

function checkTextAreaMaxLength(textBox, e) { 
    
    var maxLength = parseInt($(textBox).data("length"));
    
  
    if (!checkSpecialKeys(e)) { 
        if (textBox.value.length > maxLength - 1) textBox.value = textBox.value.substring(0, maxLength); 
   } 
  $(".char-count").html(maxLength - textBox.value.length);
    
    return true; 
} 

function checkSpecialKeys(e) { 
    if (e.keyCode != 8 && e.keyCode != 46 && e.keyCode != 37 && e.keyCode != 38 && e.keyCode != 39 && e.keyCode != 40) 
        return false; 
    else 
        return true; 
}
</script>
<script src="<?php echo e(asset('assets/backend')); ?>/js/pages/custom/user/list-datatable.js?v=7.0.6"></script>
</script>


<script>

$(document).on('change','.select_type',function(){
 var id = $(".select_type").val();
 
 if(id==1){
  $('.customers').hide(); 
  $('.stores').show();
 }else{
  $('.stores').hide(); 
  $('.customers').show();
 }

});



function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    reader.onload = function(e) {
      $('#blah').attr('src', e.target.result);
    }
    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}


$("#imgInp").change(function() {
  readURL(this);
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>