<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StaticPages extends Model
{ 

    protected $table = "tbl_static_page_editor"; 
    protected $guarded = [];
	
    //
}
