<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Device_Detail extends Model
{

	protected $table = "device_detail";
    protected $guarded = [];
}

